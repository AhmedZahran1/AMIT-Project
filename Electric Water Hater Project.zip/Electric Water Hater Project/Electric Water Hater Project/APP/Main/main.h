/*
 * main.h
 *
 * Created: 2/27/2022 8:30:55 PM
 *  Author: karim
 */ 


#ifndef MAIN_H_
#define MAIN_H_
//Configuration Drivers
#include "Configuration.h"
//Drivers for MCAL
#include "DIO.h"
#include "ADC.h"
#include "Interrupt.h"
#include "Timer0.h"
#include "TWI.h"
//Drivers for HAL
#include "OnOFF_BTN.h"
#include "Up_BTN.h"
#include "Down_BTN.h"
#include "Heating_LED.h"
#include "Cooling_LED.h"
#include "Heater_Relay.h"
#include "Cooler_Relay.h"
#include "LM35_Sensor.h"
#include "SEVSEG.h"
#include "Ext_EEPROM.h"
#include "LCD.h"

#endif /* MAIN_H_ */