/*
* Electric Water Hater Project.c
*
* Created: 2/27/2022 8:30:14 PM
* Author : karim
*/
#include "main.h"

uint16_t Temp = 0;
uint16_t Req_Temp = 0;
uint8_t iter = 0;
uint8_t read_On_Off = 1;
uint8_t statemachine = 0;
int main(void)
{
	/* Replace with your application code */
	while (1)
	{
		switch(statemachine)
		{
			case 0:/*Initialization of the system*/
			Interrupt0_Initialization();
			Interrupt1_Initialization();
			
			On_Off_BTN_Initialize();
			
			LM35_Initialize();
			LCD_Initialization();
			SEVSEG_Initialization();
			
			Heater_Initialize();
			Cooler_Initialize();
			
			HeatingLED_Initialize();
			CoolingLED_Initialize();
			
			LCD_Write_Command(0xCF);
			LCD_Write_Number(statemachine);
			_delay_ms(50);
			statemachine = 1;
			break;
			case 1:/*Start the system by press on on off button*/
			LCD_Clear();
			LCD_Write_Command(0x81);
			LCD_Write_String((uint8_t*)"Press On/Off");
			LCD_Write_Command(0xC0);
			LCD_Write_String((uint8_t*)"To Power System");
			statemachine = 2;
			break;
			case 2:/*Waiting to press on button*/
			read_On_Off = On_Off_BTN_Read();
			if(read_On_Off == 0)
			{
				read_On_Off = 1;
				statemachine = 3;
			}
			break;
			case 3:/*Power Up system*/
			LCD_Clear();
			LCD_Write_Command(0x80);
			LCD_Write_String((uint8_t*)"Loading Program");
			LCD_Write_Command(0xC0);
			for (iter = 0; iter < 16; iter++)
			{
				LCD_Write_Character('*');
				_delay_ms(250);
			}
			Temp = LM35_Read();
			Temp = ((Temp * 0.5) - 1);
			Req_Temp = Temp;
			statemachine = 5;
			break;
			case 4:/*Power Down system*/
			LCD_Clear();
			LCD_Write_Command(0x80);
			LCD_Write_String((uint8_t*)"Shutdown system");
			_delay_ms(500);
			LCD_Clear();
			LCD_Write_Command(0x80);
			LCD_Write_String((uint8_t*)"Saving Data..");
			LCD_Write_Command(0xC0);
			for (iter = 0; iter < 16; iter++)
			{
				LCD_Write_Character('*');
				_delay_ms(250);
			}
			statemachine = 1;
			break;
			case 5:/*Temperature reading*/
			LCD_Clear();
			LCD_Write_Command(0x80);
			LCD_Write_String((uint8_t*)"Temp= ");
			LCD_Write_Number(Temp);
			LCD_Write_Character(223);
			LCD_Write_Character('C');
			LCD_Write_Command(0xC0);
			LCD_Write_String((uint8_t*)"Req Temp= ");
			LCD_Write_Number(Req_Temp);
			LCD_Write_Character(223);
			LCD_Write_Character('C');
			
			statemachine = 6;
			break;
			case 6:
			read_On_Off = On_Off_BTN_Read();
			if(read_On_Off == 0)
			{
				LCD_Write_Command(0x8F);
				LCD_Write_Number(read_On_Off);
				_delay_ms(250);
				read_On_Off = 1;
				statemachine = 4;
			}
			else
			{
				statemachine = 7;
			}
			break;
			case 7:/*Compare between Actual Temp and Required Temp*/
			Temp = LM35_Read();
			Temp = ((Temp * 0.5) - 1);
			LCD_Clear();
			if (Req_Temp < Temp)
			{
				Heater_ON();
				HeatingLED_ON();
				LCD_Write_Command(0x80);
				LCD_Write_String((uint8_t*)"Temp= ");
				LCD_Write_Number(Temp);
				LCD_Write_Character(223);
				LCD_Write_Character('C');
				LCD_Write_Command(0xC0);
				LCD_Write_String((uint8_t*)"Req Temp= ");
				LCD_Write_Number(Req_Temp);
				LCD_Write_Character(223);
				LCD_Write_Character('C');
				_delay_ms(125);
				LCD_Write_Command(0xCF);
				LCD_Write_Number(statemachine);
			}
			else if(Req_Temp > Temp)
			{
				Cooler_ON();
				CoolingLED_ON();
				LCD_Write_Command(0x80);
				LCD_Write_String((uint8_t*)"Temp= ");
				LCD_Write_Number(Temp);
				LCD_Write_Character(223);
				LCD_Write_Character('C');
				LCD_Write_Command(0xC0);
				LCD_Write_String((uint8_t*)"Req Temp= ");
				LCD_Write_Number(Req_Temp);
				LCD_Write_Character(223);
				LCD_Write_Character('C');
				_delay_ms(125);
				LCD_Write_Command(0xCF);
				LCD_Write_Number(statemachine);
			}
			else if(Req_Temp == Temp)
			{
				Heater_OFF();
				HeatingLED_OFF();
				Cooler_OFF();
				CoolingLED_OFF();
			}
			statemachine = 8;
			_delay_ms(125);
			break;
			case 8:/*Show Temperature*/
			LCD_Clear();
			LCD_Write_Command(0xCF);
			LCD_Write_Number(statemachine);
			LCD_Write_Command(0x80);
			LCD_Write_String((uint8_t*)"Temp= ");
			LCD_Write_Number(Temp);
			LCD_Write_Character(223);
			LCD_Write_Character('C');
			LCD_Write_Command(0xC0);
			LCD_Write_String((uint8_t*)"Req Temp= ");
			LCD_Write_Number(Req_Temp);
			LCD_Write_Character(223);
			LCD_Write_Character('C');
			if(Req_Temp == Temp)
			{
				Heater_OFF();
				HeatingLED_OFF();
				Cooler_OFF();
				CoolingLED_OFF();
			}
			statemachine = 9;
			break;
			case 9 :
			LCD_Write_Command(0xCF);
			LCD_Write_Number(statemachine);
			read_On_Off = On_Off_BTN_Read();
			if(read_On_Off == 0)
			{
				read_On_Off = 1;
				statemachine = 4;
				break;
			}
			else
			{
				if (Req_Temp < Temp || Req_Temp > Temp)
				{
					statemachine = 7;
				}
				else
				{
					Temp = LM35_Read();
					Temp = ((Temp * 0.5) - 1);
					statemachine = 8;
					_delay_ms(250);
				}
			}
			if(Req_Temp == Temp)
			{
				Heater_OFF();
				HeatingLED_OFF();
				Cooler_OFF();
				CoolingLED_OFF();
				statemachine = 8;
			}
			break;
		}
	}
	return 0;
}
ISR(INT0_vect)/*Up button for increasing temperature*/
{
	Req_Temp++;
	LCD_Clear();
	LCD_Write_Command(0x80);
	LCD_Write_String((uint8_t*)"Temp= ");
	LCD_Write_Number(Temp);
	LCD_Write_Character(223);
	LCD_Write_Character('C');
	LCD_Write_Command(0xC0);
	LCD_Write_String((uint8_t*)"Req Temp= ");
	LCD_Write_Number(Req_Temp);
	LCD_Write_Character(223);
	LCD_Write_Character('C');
	statemachine = 7;
}
ISR(INT1_vect)/*Down button for decreasing temperature*/
{
	Req_Temp--;
	LCD_Clear();
	LCD_Write_Command(0x80);
	LCD_Write_String((uint8_t*)"Temp= ");
	LCD_Write_Number(Temp);
	LCD_Write_Character(223);
	LCD_Write_Character('C');
	LCD_Write_Command(0xC0);
	LCD_Write_String((uint8_t*)"Req Temp= ");
	LCD_Write_Number(Req_Temp);
	LCD_Write_Character(223);
	LCD_Write_Character('C');
	statemachine = 7;
}