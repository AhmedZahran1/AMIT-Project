/*
 * Interrupt.h
 *
 * Created: 12/10/2021 1:37:40 PM
 *  Author: karim
 */ 


#ifndef INTERRUPT_H_
#define INTERRUPT_H_

#include "Interrupt_Configuration.h"

void Interrupt0_Initialization(void);
void Interrupt1_Initialization(void);

#endif /* INTERRUPT_H_ */