/*
 * ADC_Address.h
 *
 * Created: 12/11/2021 1:17:31 PM
 *  Author: karim
 */ 


#ifndef ADC_ADDRESS_H_
#define ADC_ADDRESS_H_
 
#define ADC_DATA (*(volatile uint16_t*) 0x24)
/*
#define ADCH   (*(volatile uint8_t*) 0x25)
#define ADCL   (*(volatile uint8_t*) 0x24)
#define ADMUX  (*(volatile uint8_t*) 0x27)
#define SFIOR  (*(volatile uint8_t*) 0x50)
#define ADCSRA (*(volatile uint8_t*) 0x26)
*/

#endif /* ADC_ADDRESS_H_ */