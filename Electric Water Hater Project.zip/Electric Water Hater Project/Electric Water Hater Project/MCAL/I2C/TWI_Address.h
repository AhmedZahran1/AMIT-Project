/*
 * TWI_Address.h
 *
 * Created: 1/8/2022 9:48:59 AM
 *  Author: karim
 */ 


#ifndef TWI_ADDRESS_H_
#define TWI_ADDRESS_H_

/*
#define TWCR (*(volatile uint8_t*) 0x56)
#define TWDR (*(volatile uint8_t*) 0x23)
#define TWAR (*(volatile uint8_t*) 0x22)
#define TWSR (*(volatile uint8_t*) 0x21)
#define TWBR (*(volatile uint8_t*) 0x20)
*/

#endif /* TWI_ADDRESS_H_ */