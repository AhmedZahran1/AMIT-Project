/*
 * Heater_Relay.h
 *
 * Created: 2/27/2022 9:20:06 PM
 *  Author: karim
 */ 


#ifndef HEATER_RELAY_H_
#define HEATER_RELAY_H_

#include "Heater_Relay_Configuration.h"

void Heater_Initialize(void);
void Heater_ON(void);
void Heater_OFF(void);
void Heater_TOGGLE(void);



#endif /* HEATER_RELAY_H_ */