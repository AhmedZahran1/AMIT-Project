/*
 * Heater_Relay.c
 *
 * Created: 2/27/2022 9:20:00 PM
 *  Author: karim
 */ 

#include "Heater_Relay.h"

void Heater_Initialize(void)
{
	DIO_SetPinDirection(Heater_Port, Heater, Heater_Out);
}
void Heater_ON(void)
{
	DIO_SetPinValue(Heater_Port, Heater, Heater_High);
}
void Heater_OFF(void)
{
	DIO_SetPinValue(Heater_Port, Heater, Heater_Low);
}
void Heater_TOGGLE(void)
{
	DIO_TogglePinValue(Heater_Port, Heater);
}