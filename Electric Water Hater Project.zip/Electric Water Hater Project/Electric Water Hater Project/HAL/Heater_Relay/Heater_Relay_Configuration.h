/*
 * Heater_Relay_Configuration.h
 *
 * Created: 2/27/2022 9:20:15 PM
 *  Author: karim
 */ 


#ifndef HEATER_RELAY_CONFIGURATION_H_
#define HEATER_RELAY_CONFIGURATION_H_


#include "Configuration.h"
#include "DIO.h"

#define Heater_Port DIO_PORTD
#define Heater_Out  DIO_OUTPUT
#define Heater      DIO_PIN6
#define Heater_High DIO_HIGH
#define Heater_Low  DIO_LOW


#endif /* HEATER_RELAY_CONFIGURATION_H_ */