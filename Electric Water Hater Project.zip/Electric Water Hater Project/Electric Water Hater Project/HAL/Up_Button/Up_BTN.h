/*
 * Up_BTN.h
 *
 * Created: 2/27/2022 9:14:02 PM
 *  Author: karim
 */ 


#ifndef UP_BTN_H_
#define UP_BTN_H_

#include "Up_BTN_Configuration.h"


void Up_BTN_Initialize(void);

uint8_t Up_BTN_Read(void);

#endif /* UP_BTN_H_ */