/*
 * Up_BTN_Configuration.h
 *
 * Created: 2/27/2022 9:14:17 PM
 *  Author: karim
 */ 


#ifndef UP_BTN_CONFIGURATION_H_
#define UP_BTN_CONFIGURATION_H_

#include "Configuration.h"
#include "DIO.h"

#define Up_BTN     DIO_PIN7
#define Up_BTN_PRT DIO_PORTB
#define Up_BTN_INP DIO_INPUT


#endif /* UP_BTN_CONFIGURATION_H_ */