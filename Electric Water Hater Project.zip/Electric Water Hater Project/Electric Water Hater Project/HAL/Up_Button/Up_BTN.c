/*
 * Up_BTN.c
 *
 * Created: 2/27/2022 9:14:58 PM
 *  Author: karim
 */ 



#include "Up_BTN.h"


void Up_BTN_Initialize(void)
{
	DIO_SetPinDirection(Up_BTN_PRT, Up_BTN, Up_BTN_INP);
	DIO_SetPinPullUp(Up_BTN_PRT, Up_BTN);
}

uint8_t Up_BTN_Read(void)
{
	uint8_t read = 1;
	_delay_ms(10);
	read = DIO_ReadPinValue(Up_BTN_PRT, Up_BTN);
	return read;
}
