/*
* Cooling_LED_Configuration.h
*
* Created: 2/27/2022 9:19:31 PM
*  Author: karim
*/


#ifndef COOLING_LED_CONFIGURATION_H_
#define COOLING_LED_CONFIGURATION_H_

#include "Configuration.h"
#include "DIO.h"

#define Cooling_Port DIO_PORTC

#define Cooling_Out  DIO_OUTPUT

#define Cooling      DIO_PIN3

#define Cooling_High DIO_HIGH

#define Cooling_Low  DIO_LOW



#endif /* COOLING_LED_CONFIGURATION_H_ */