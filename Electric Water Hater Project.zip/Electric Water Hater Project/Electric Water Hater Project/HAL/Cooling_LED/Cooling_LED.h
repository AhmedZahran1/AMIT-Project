/*
 * Cooling_LED.h
 *
 * Created: 2/27/2022 9:19:22 PM
 *  Author: karim
 */ 


#ifndef COOLING_LED_H_
#define COOLING_LED_H_

#include "Cooling_LED_Configuration.h"

void CoolingLED_Initialize(void);
void CoolingLED_ON(void);
void CoolingLED_OFF(void);
void CoolingLED_TOGGLE(void);



#endif /* COOLING_LED_H_ */