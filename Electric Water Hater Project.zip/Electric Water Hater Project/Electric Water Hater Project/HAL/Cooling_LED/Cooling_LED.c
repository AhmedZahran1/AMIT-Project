/*
 * Cooling_LED.c
 *
 * Created: 2/27/2022 9:19:38 PM
 *  Author: karim
 */ 


#include "Cooling_LED.h"

void CoolingLED_Initialize(void)
{
	DIO_SetPinDirection(Cooling_Port, Cooling, Cooling_Out);
}
void CoolingLED_ON(void)
{
	DIO_SetPinValue(Cooling_Port, Cooling, Cooling_High);
}
void CoolingLED_OFF(void)
{
	DIO_SetPinValue(Cooling_Port, Cooling, Cooling_Low);
}
void CoolingLED_TOGGLE(void)
{
	DIO_TogglePinValue(Cooling_Port, Cooling);
}