/*
 * OnOFF_BTN_Configuration.h
 *
 * Created: 2/27/2022 9:13:32 PM
 *  Author: karim
 */ 


#ifndef ONOFF_BTN_CONFIGURATION_H_
#define ONOFF_BTN_CONFIGURATION_H_

#include "Configuration.h"
#include "DIO.h"

#define ON_OFF_BTN     DIO_PIN4
#define ON_OFF_BTN_PRT DIO_PORTD
#define ON_OFF_BTN_INP DIO_INPUT



#endif /* ONOFF_BTN_CONFIGURATION_H_ */