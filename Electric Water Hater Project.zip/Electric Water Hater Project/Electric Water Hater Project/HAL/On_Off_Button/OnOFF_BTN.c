/*
 * OnOFF_BTN.c
 *
 * Created: 2/27/2022 9:13:14 PM
 *  Author: karim
 */ 


#include "OnOFF_BTN.h"

void On_Off_BTN_Initialize(void)
{
	DIO_SetPinDirection(ON_OFF_BTN_PRT, ON_OFF_BTN, ON_OFF_BTN_INP);
	DIO_SetPinPullUp(ON_OFF_BTN_PRT, ON_OFF_BTN);
}

uint8_t On_Off_BTN_Read(void)
{
	uint8_t read = 1;
	_delay_ms(10);
	read = DIO_ReadPinValue(ON_OFF_BTN_PRT, ON_OFF_BTN);
	return read;
}
