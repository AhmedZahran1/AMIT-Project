/*
 * OnOFF_BTN.h
 *
 * Created: 2/27/2022 9:13:22 PM
 *  Author: karim
 */ 


#ifndef ONOFF_BTN_H_
#define ONOFF_BTN_H_

#include "OnOFF_BTN_Configuration.h"


void On_Off_BTN_Initialize(void);

uint8_t On_Off_BTN_Read(void);



#endif /* ONOFF_BTN_H_ */