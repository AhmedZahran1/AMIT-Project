/*
 * Down_BTN_Configuration.h
 *
 * Created: 2/27/2022 9:08:54 PM
 *  Author: karim
 */ 


#ifndef DOWN_BTN_CONFIGURATION_H_
#define DOWN_BTN_CONFIGURATION_H_

#include "Configuration.h"
#include "DIO.h"

#define Down_BTN     DIO_PIN6
#define Down_BTN_PRT DIO_PORTB
#define Down_BTN_INP DIO_INPUT


#endif /* DOWN_BTN_CONFIGURATION_H_ */