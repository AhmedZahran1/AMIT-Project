/*
 * Down_BTN.c
 *
 * Created: 2/27/2022 9:10:16 PM
 *  Author: karim
 */ 


#include "Down_BTN.h"


void Down_BTN_Initialize(void)
{
	DIO_SetPinDirection(Down_BTN_PRT, Down_BTN, Down_BTN_INP);
	DIO_SetPinPullUp(Down_BTN_PRT, Down_BTN);
}
uint8_t Down_BTN_Read(void)
{
	uint8_t read = 1;
	_delay_ms(10);
	read = DIO_ReadPinValue(Down_BTN_PRT, Down_BTN);
	return read;
}
