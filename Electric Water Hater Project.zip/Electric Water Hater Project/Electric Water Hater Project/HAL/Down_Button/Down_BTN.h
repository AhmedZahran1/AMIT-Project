/*
 * Down_BTN.h
 *
 * Created: 2/27/2022 9:09:44 PM
 *  Author: karim
 */ 


#ifndef DOWN_BTN_H_
#define DOWN_BTN_H_


#include "Down_BTN_Configuration.h"


void Down_BTN_Initialize(void);

uint8_t Down_BTN_Read(void);


#endif /* DOWN_BTN_H_ */