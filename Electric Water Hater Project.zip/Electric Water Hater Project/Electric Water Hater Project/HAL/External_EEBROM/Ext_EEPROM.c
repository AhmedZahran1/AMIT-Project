/*
 * Ext_EEPROM.c
 *
 * Created: 2/27/2022 9:15:41 PM
 *  Author: karim
 */ 
