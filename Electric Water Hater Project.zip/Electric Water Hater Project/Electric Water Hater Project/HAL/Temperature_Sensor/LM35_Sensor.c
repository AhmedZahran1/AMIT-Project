/*
 * LM35_Sensor.c
 *
 * Created: 2/27/2022 9:12:58 PM
 *  Author: karim
 */ 


#include "LM35_Sensor.h"


void LM35_Initialize(void)
{
	ADC_Initialization(LM35);
}
uint16_t LM35_Read(void)
{
	uint16_t Temp = 0;
	_delay_ms(10);
	Temp = ADC_Read();
	return Temp;
}