/*
 * LM35_Sensor_Configuration.h
 *
 * Created: 2/27/2022 9:12:52 PM
 *  Author: karim
 */ 


#ifndef LM35_SENSOR_CONFIGURATION_H_
#define LM35_SENSOR_CONFIGURATION_H_

#include "Configuration.h"
#include "ADC.h"

#define LM35  0



#endif /* LM35_SENSOR_CONFIGURATION_H_ */