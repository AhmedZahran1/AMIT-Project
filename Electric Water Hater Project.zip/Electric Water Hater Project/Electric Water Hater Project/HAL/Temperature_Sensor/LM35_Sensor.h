/*
 * LM35_Sensor.h
 *
 * Created: 2/27/2022 9:12:41 PM
 *  Author: karim
 */ 


#ifndef LM35_SENSOR_H_
#define LM35_SENSOR_H_

#include "LM35_Sensor_Configuration.h"

void LM35_Initialize(void);

uint16_t LM35_Read(void);


#endif /* LM35_SENSOR_H_ */