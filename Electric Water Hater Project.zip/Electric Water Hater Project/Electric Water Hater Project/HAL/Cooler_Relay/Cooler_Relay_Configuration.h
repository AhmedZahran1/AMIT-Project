/*
 * Cooler_Relay_Configuration.h
 *
 * Created: 2/27/2022 10:53:46 PM
 *  Author: karim
 */ 


#ifndef COOLER_RELAY_CONFIGURATION_H_
#define COOLER_RELAY_CONFIGURATION_H_

#include "Configuration.h"
#include "DIO.h"

#define Cooler_Port DIO_PORTD
#define Cooler_Out  DIO_OUTPUT
#define Cooler      DIO_PIN5
#define Cooler_High DIO_HIGH
#define Cooler_Low  DIO_LOW



#endif /* COOLER_RELAY_CONFIGURATION_H_ */