/*
 * Cooler_Relay.h
 *
 * Created: 2/27/2022 9:20:34 PM
 *  Author: karim
 */ 


#ifndef COOLER_RELAY_H_
#define COOLER_RELAY_H_

#include "Cooler_Relay_Configuration.h"

void Cooler_Initialize(void);
void Cooler_ON(void);
void Cooler_OFF(void);
void Cooler_TOGGLE(void);



#endif /* COOLER_RELAY_H_ */