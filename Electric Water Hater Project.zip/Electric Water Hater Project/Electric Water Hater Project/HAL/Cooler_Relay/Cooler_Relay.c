/*
 * Cooler_Relay.c
 *
 * Created: 2/27/2022 10:53:33 PM
 *  Author: karim
 */ 


#include "Cooler_Relay.h"

void Cooler_Initialize(void)
{
	DIO_SetPinDirection(Cooler_Port, Cooler, Cooler_Out);
}
void Cooler_ON(void)
{
	DIO_SetPinValue(Cooler_Port, Cooler, Cooler_High);
}
void Cooler_OFF(void)
{
	DIO_SetPinValue(Cooler_Port, Cooler, Cooler_Low);
}
void Cooler_TOGGLE(void)
{
	DIO_TogglePinValue(Cooler_Port, Cooler);
}