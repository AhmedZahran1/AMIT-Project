/*
* Heating_LED.c
*
* Created: 2/27/2022 9:10:31 PM
*  Author: karim
*/

#include "Heating_LED.h"

void HeatingLED_Initialize(void)
{
	DIO_SetPinDirection(Heating_Port, Heating, Heating_Out);
}
void HeatingLED_ON(void)
{
	DIO_SetPinValue(Heating_Port, Heating, Heating_High);
}
void HeatingLED_OFF(void)
{
	DIO_SetPinValue(Heating_Port, Heating, Heating_Low);
}
void HeatingLED_TOGGLE(void)
{
	DIO_TogglePinValue(Heating_Port, Heating);
}