/*
 * Heating_LED_Configuration.h
 *
 * Created: 2/27/2022 9:10:56 PM
 *  Author: karim
 */ 


#ifndef HEATING_LED_CONFIGURATION_H_
#define HEATING_LED_CONFIGURATION_H_

#include "Configuration.h"
#include "DIO.h"

#define Heating_Port DIO_PORTC

#define Heating_Out  DIO_OUTPUT

#define Heating DIO_PIN4

#define Heating_High DIO_HIGH

#define Heating_Low  DIO_LOW


#endif /* HEATING_LED_CONFIGURATION_H_ */