/*
 * Heating_LED.h
 *
 * Created: 2/27/2022 9:10:38 PM
 *  Author: karim
 */ 


#ifndef HEATING_LED_H_
#define HEATING_LED_H_

#include "Heating_LED_Configuration.h"

void HeatingLED_Initialize(void);
void HeatingLED_ON(void);
void HeatingLED_OFF(void);
void HeatingLED_TOGGLE(void);



#endif /* HEATING_LED_H_ */